﻿using CommunityToolkit.Maui.Alerts;

namespace ColorMaker
{
    public partial class MainPage : ContentPage
    {
        private bool isRandom;
        private string hexValue;
        public MainPage()
        {
            InitializeComponent();
        }

        private void slider_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            if (!isRandom)
            {
                var red = sldRed.Value;
                var green = sldGreen.Value;
                var blue = sldBlue.Value;
                Color color = Color.FromRgb(red, green, blue);
                setcolor(color);
            }
        }

        private void setcolor(Color color)
        {
            btnGenColor.Background = color;
            gridCotainer.Background=color;
            hexValue = color.ToHex();
            lblHex.Text = hexValue;
        }

        private void btnGenColor_Clicked(object sender, EventArgs e)
        {
            isRandom = true;
            var random = new Random();
            var color = Color.FromRgb(random.Next(0, 265), random.Next(0, 265), random.Next(0, 265));
            sldRed.Value = color.Red;
            sldGreen.Value = color.Green;
            sldBlue.Value = color.Blue;
            setcolor(color);
            isRandom = false;
        }

        private async void ImageButton_Clicked(object sender, EventArgs e)
        {
            await Clipboard.SetTextAsync(hexValue);
            var toast = Toast.Make("Color copied", CommunityToolkit.Maui.Core.ToastDuration.Short,
                12);
            await toast.Show();
        }
    }
}