using Mauiverter.MVVM.ViewModels;

namespace Mauiverter.MVVM.Views;

public partial class MenuView : ContentPage
{
	public MenuView()
	{
		InitializeComponent();
	}

    private void TapGestureRecognizer_Tapped(object sender, EventArgs e)
    {
		var element = (Grid)sender;
		var option = ((Label)element.Children.LastOrDefault()).Text;
		var view = new ConverterView() 
		{
            BindingContext= new ConverterViewModel(option)
		};
		Navigation.PushAsync(view);
    }
}