﻿using CollectionViewDemo.MVVM.Models;
using Microsoft.Maui.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionViewDemo.Selectors
{
    public class ProductDataTemplateSelector : DataTemplateSelector
    {
        protected override DataTemplate OnSelectTemplate(object item, BindableObject container)
        {
            var product = item as Product;
            if(!product.HasOffer)
            {
                Application.Current.Resources.TryGetValue("productStyle", out var productStyle);
                return productStyle as DataTemplate;
            }
            Application.Current.Resources.TryGetValue("offerStyle", out var offerStyle);
            return offerStyle as DataTemplate;
        }
    }
}
