﻿namespace PerfectPay
{
    public partial class MainPage : ContentPage
    {
        private decimal totalBill = 0;
        private int totalPerson = 1;
        private int tipPerc = 0;
        public MainPage()
        {
            InitializeComponent();
        }

        private decimal CaluateSplit()
        {
            var totalPersonAmout = totalBill / totalPerson;
            return Math.Round(totalPersonAmout,2);
        }

        private decimal CalcualteTip()
        {
            var subTot = CaluateSplit();
            var tipPerPerson = (tipPerc * subTot) / 100;
            return Math.Round( tipPerPerson,2);
        }

        private void txtBillAmout_Completed(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtBillAmout.Text))
                totalBill = 0;
            totalBill = Convert.ToDecimal(txtBillAmout.Text);
            ApplyChanges();
        }

        private void ApplyChanges()
        {
            var sp = CaluateSplit();
            var tp = CalcualteTip();
            lblSubtotal.Text = $"{sp:C}";
            lblTipTop.Text = $"{tp:C}";
            lblTotal.Text = $"{(tp + sp):C}";
            sldTip.Value = Convert.ToDouble (tipPerc);
            lblTip.Text = $"Tip : {sldTip.Value}%";
        }

        private void btn10_Clicked(object sender, EventArgs e)
        {
            tipPerc = 10;
            ApplyChanges();
        }

        private void btn15_Clicked(object sender, EventArgs e)
        {
            tipPerc = 15;
            ApplyChanges();
        }

        private void bt210_Clicked(object sender, EventArgs e)
        {
            tipPerc = 20;
            ApplyChanges();

        }

        private void btnMinus_Clicked(object sender, EventArgs e)
        {
            if (totalPerson != 1)
            {
                totalPerson = totalPerson - 1;
                lblSplitPerson.Text = totalPerson.ToString();
                ApplyChanges();
            }
        }

        private void btnPlus_Clicked(object sender, EventArgs e)
        {
            totalPerson = totalPerson + 1;
            lblSplitPerson.Text = totalPerson.ToString();
            ApplyChanges();
        }

        private void sldTip_ValueChanged(object sender, ValueChangedEventArgs e)
        {
            tipPerc = Convert.ToInt32(sldTip.Value);
            ApplyChanges();
        }
    }
}