﻿using SkiaSharp.Extended.UI.Controls;
using System.Globalization;

namespace MauiWeather.Converters
{
    public class WeatherImageConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            var lottienSource = new SKFileLottieImageSource();            
            var code = (int)value;
            switch(code)
            {
                case 0:
                    lottienSource.File = "sunny.json";
                    return lottienSource;
                case 1:
                case 2:
                case 3:
                    lottienSource.File = "mist.json";
                    return lottienSource;
                case 45:
                case 48:
                    lottienSource.File = "foggy.json";
                    return lottienSource;
                case 51:
                case 53:
                case 55:
                    lottienSource.File = "partly-shower.json";
                    return lottienSource;
                case 56:
                case 57:
                    lottienSource.File = "windy.json";
                    return lottienSource;
                case 61:
                case 63:
                case 65:
                    lottienSource.File = "thunder.json"; 
                    return lottienSource;
                case 66:
                case 67:
                    lottienSource.File = "stormshowersday.json";
                    return lottienSource;
                case 71:
                case 73:
                case 75:
                    lottienSource.File = "snow.json";
                    return lottienSource;
                case 77:
                    lottienSource.File ="snow-sunny.json";
                    return lottienSource;
                case 80:
                case 81:
                case 82:
                    lottienSource.File = "partly-shower.json";
                    return lottienSource;
                case 85:
                case 86:
                    lottienSource.File = "snow.json";
                    return lottienSource;
                case 95:
                    lottienSource.File = "thunder.json";
                    return lottienSource;
                case 96:
                case 99:
                    lottienSource.File = "stormshowersday.json";
                    return lottienSource;
                default:
                    lottienSource.File = "sunny.json";
                    return lottienSource;
            }
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
