﻿using MauiWeather.MVVM.Models;
using PropertyChanged;
using System.Text.Json;
using System.Windows.Input;

namespace MauiWeather.MVVM.ViewModels
{
    [AddINotifyPropertyChangedInterface]
    public class WeatherViewModel
    {
        public WeatherData WeatherData { get; set; }
        private HttpClient client;
        public string PlaceName { get; set; }
        public DateTime Date { get; set; } = DateTime.Now;
        public bool IsVisible { get; set; }
        public bool IsLoading { get; set; }
        public WeatherViewModel()
        {
            client = new HttpClient();
        }
        public ICommand SearchCommand => new Command(async (searchText) =>
        {
            IsLoading = true;
            PlaceName = searchText.ToString();
            if (!string.IsNullOrEmpty(PlaceName))
            {
                var location = await GetCoordinatesAsync(PlaceName);
                await GetWeather(location);
            }
            IsLoading = false;
        });
        private async Task<Location> GetCoordinatesAsync(string address)
        {
            var locations = await Geocoding.Default.GetLocationsAsync(address);
            var location = locations?.FirstOrDefault();
            if(location != null)
            {
                return location;
            }
            return location;
        }

        private async Task GetWeather(Location location)
        {
            var url = $"https://api.open-meteo.com/v1/forecast?latitude={location.Latitude}&longitude={location.Longitude}&daily=weathercode,temperature_2m_max,temperature_2m_min&current_weather=true&timezone=America%2FChicago";
            var response = await client.GetAsync(url);
            if (response.IsSuccessStatusCode)
            {
                using (var responseStream = await response.Content.ReadAsStreamAsync())
                {
                    WeatherData = await JsonSerializer.DeserializeAsync<WeatherData>(responseStream);
                    for (int i = 0; i < WeatherData.daily.weathercode.Length; i++)
                    {
                        WeatherData.daily2.Add(
                            new Daily2()
                            {
                                weathercode = WeatherData.daily.weathercode[i],
                                time = WeatherData.daily.time[i],
                                temperature_2m_min = WeatherData.daily.temperature_2m_min[i],
                                temperature_2m_max = WeatherData.daily.temperature_2m_max[i]
                            });
                    }
                }
                IsVisible = true;
            }
        }
    }
}
