using System.Globalization;
using Tasker.MVVM.Models;
using Tasker.MVVM.ViewModels;

namespace Tasker.MVVM.Views;

public partial class NewTask : ContentPage
{
	public NewTask()
	{
		InitializeComponent();
		//BindingContext = new NewTaskViewModel();
	}

    private async void AddTask_Clicked(object sender, EventArgs e)
    {
		var vm = BindingContext as NewTaskViewModel;
		var selectedCategory = vm.Categories.FirstOrDefault(x => x.IsSelected);
		if (selectedCategory != null)
		{
			vm.Tasks.Add( new MyTask()
			{
				TaskName = vm.Task,
				CategoryId = selectedCategory.Id
			});
			await Navigation.PopAsync();
		}
		else
		{ await DisplayAlert("Invalid Selection", "Please select catgory", "Ok"); }
    }

    private async void AddCategory_Clicked(object sender, EventArgs e)
    {
        var vm = BindingContext as NewTaskViewModel;
		var category = await DisplayPromptAsync("New Category", "Write the new Category Name",
			maxLength: 15, keyboard: Keyboard.Text);
		var r = new Random();
		if (!string.IsNullOrEmpty(category))
		{
			var nCategory = new Category()
			{
				Id = vm.Categories.Max(x => x.Id) + 1,
				Color = Color.FromRgb(r.Next(0, 255), r.Next(0, 255), r.Next(0, 255)).ToHex(),
				CategoryName = category
			};
			vm.Categories.Add(nCategory);
		}
    }
}