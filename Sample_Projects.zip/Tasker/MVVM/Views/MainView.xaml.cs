using PropertyChanged;
using Tasker.MVVM.ViewModels;

namespace Tasker.MVVM.Views;

[AddINotifyPropertyChangedInterface]
public partial class MainView : ContentPage
{
	private MainViewModel mainViewModel =	new MainViewModel();
	public MainView()
	{
		InitializeComponent();
		BindingContext = mainViewModel;

    }

    private void chkBox_CheckedChanged(object sender, CheckedChangedEventArgs e)
    {
        mainViewModel.UpdateData();
    }

    private void Button_Clicked(object sender, EventArgs e)
    {
        var _newTaskViewModel = new NewTaskViewModel()
        {
            Categories = mainViewModel.Categories,
            Tasks = mainViewModel.Tasks
        };
        var newTaskModel = new NewTask()
        {
            BindingContext = _newTaskViewModel
        };
        Navigation.PushAsync(newTaskModel);
    }
}